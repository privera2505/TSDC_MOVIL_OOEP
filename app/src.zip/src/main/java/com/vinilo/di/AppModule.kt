package com.vinilo.di

class AppModule {
}