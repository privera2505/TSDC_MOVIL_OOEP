package com.vinilo.ui.awards

import androidx.fragment.app.Fragment

class AwardsFragment: Fragment()  {
}