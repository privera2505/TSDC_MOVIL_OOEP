package com.vinilo.data.remote.dto

data class AwardDto(
    val id: Int,
    val name: String,
    val description: String?,
    val organization: String?,
)
