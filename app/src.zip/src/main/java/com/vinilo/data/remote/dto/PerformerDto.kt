package com.vinilo.data.remote.dto

data class PerformerDto(
    val id: Int,
    val name: String,
    val image: String,
    val description: String,
    val birthDate: String
)