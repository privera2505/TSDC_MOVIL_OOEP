package com.vinilo.data.remote.dto

data class PerformerWinnerDto(
    val id: Int,
    val premiationDate: String,
    val performer: PerformerDto
)