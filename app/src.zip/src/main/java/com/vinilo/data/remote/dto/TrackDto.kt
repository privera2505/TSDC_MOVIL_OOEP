package com.vinilo.data.remote.dto

data class TrackDto(
    val name: String,
    val duration: String
)