package com.vinilo.domain.model

data class Track(
    val name: String,
    val duration: String
)
