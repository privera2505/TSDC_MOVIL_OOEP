package com.vinilo.domain.model

data class Comment(
    val id: Int,
    val description: String,
    val rating: Double
)
