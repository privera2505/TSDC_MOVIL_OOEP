package com.vinilo.domain.model

data class CollectorAlbum(
    val id: Int,
    val price: Double,
    val status: String
)