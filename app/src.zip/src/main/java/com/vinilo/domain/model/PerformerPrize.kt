package com.vinilo.domain.model

import java.util.Date

data class PerformerPrize (

    val id: Int,
    val premiationDate: Date

)