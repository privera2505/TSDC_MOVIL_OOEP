package com.vinilo

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VinilosApp : Application()